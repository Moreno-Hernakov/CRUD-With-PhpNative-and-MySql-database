-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 07 Okt 2021 pada 08.02
-- Versi server: 10.1.36-MariaDB
-- Versi PHP: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spp_sekolah`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_kasir`
--

CREATE TABLE `tabel_kasir` (
  `id` int(11) NOT NULL,
  `id_siswa` int(10) NOT NULL,
  `nama_kasir` varchar(50) NOT NULL,
  `tanggal_pembayran` date NOT NULL,
  `created_date` date NOT NULL,
  `updated_date` date NOT NULL,
  `is_active` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_siswa`
--

CREATE TABLE `tabel_siswa` (
  `id` int(11) NOT NULL,
  `nama_siswa` varchar(50) NOT NULL,
  `kode_siswa` varchar(20) NOT NULL,
  `no_telp_siswa` varchar(12) NOT NULL,
  `created_date` date NOT NULL,
  `updated_date` date NOT NULL,
  `is_active` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tabel_siswa`
--

INSERT INTO `tabel_siswa` (`id`, `nama_siswa`, `kode_siswa`, `no_telp_siswa`, `created_date`, `updated_date`, `is_active`) VALUES
(1, '  Moreno  Hernakov', '  101', '  0821311231', '0000-00-00', '2021-10-06', 1),
(2, '  agus yudhaa', ' 102', '  031415428', '0000-00-00', '2021-10-06', 0),
(3, ' bamabang', '103', '08213143', '0000-00-00', '2021-10-06', 0),
(8, ' sisil', '104', ' 08219229314', '0000-00-00', '2021-10-06', 0),
(12, ' rara', '105', ' 08219229314', '0000-00-00', '2021-10-06', 0),
(13, ' nono', '106', ' 08214143922', '0000-00-00', '2021-10-06', 0),
(17, ' lola', '107', ' 03141004100', '0000-00-00', '2021-10-06', 0),
(18, ' rere sksksk', ' 108', ' 03129292123', '0000-00-00', '2021-10-06', 0),
(19, ' lili palili', ' 109', ' 07132187654', '2021-10-06', '2021-10-07', 0),
(20, ' sandhika g.', ' 110', ' 04131645338', '2021-10-07', '2021-10-07', 0);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tabel_kasir`
--
ALTER TABLE `tabel_kasir`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_siswa` (`id_siswa`);

--
-- Indeks untuk tabel `tabel_siswa`
--
ALTER TABLE `tabel_siswa`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tabel_kasir`
--
ALTER TABLE `tabel_kasir`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tabel_siswa`
--
ALTER TABLE `tabel_siswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tabel_kasir`
--
ALTER TABLE `tabel_kasir`
  ADD CONSTRAINT `tabel_kasir_ibfk_1` FOREIGN KEY (`id_siswa`) REFERENCES `tabel_siswa` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
